package design_patterns.state_pattern.hw;

/**
 * Created by ${YogenRai} on 4/23/2016.
 */
public abstract class AccountState {
    abstract void computePoints(FFAccount account,int newMiles);
}
