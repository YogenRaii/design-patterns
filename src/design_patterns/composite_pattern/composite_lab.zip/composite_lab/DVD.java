package design_patterns.composite_pattern.composite_lab;

/**
 * Created by ${YogenRai} on 4/9/2016.
 */
public class DVD {
    private String title;
    public DVD(String title){
        this.title =  title;
    }

    public String getTitle() {
        return title;
    }
}
