package design_patterns.strategy_pattern.strategy_pattern_lab.domain;

/**
 * Created by ${YogenRai} on 4/2/2016.
 */
public interface AccountType {
    double calculateInterest(double balance);
}
