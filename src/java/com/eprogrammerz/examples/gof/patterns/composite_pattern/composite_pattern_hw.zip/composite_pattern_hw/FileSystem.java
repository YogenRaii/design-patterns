package design_patterns.composite_pattern.composite_pattern_hw;

/**
 * Created by ${YogenRai} on 4/9/2016.
 */
public interface FileSystem {
    void print();
    int getSizeInBytes();
}
