package design_patterns.strategy_pattern.hw;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 */
public class Application {

    public static void main(String[] args) {
        drawGeometricShape();
    }

    /**
     * 
     */
    public static void drawGeometricShape() {
        List<DrawCanvas> canvases = new ArrayList<DrawCanvas>(){
            {
                add(new DrawLine());
                add(new DrawCircle());
                add(new DrawRectangle());
            }
        };

        for (DrawCanvas canvas:canvases){
            canvas.draw();
        }
    }

}