package design_patterns.strategy_pattern.hw;

/**
 * 
 */
public class DrawRectangle implements DrawCanvas {

    /**
     * Default constructor
     */
    public DrawRectangle() {
    }

    /**
     * 
     */
    public void draw() {
        System.out.println("Rectangle drawn");
    }

}