package design_patterns.strategy_pattern.hw;

/**
 * 
 */
public class DrawCircle implements DrawCanvas {

    /**
     * Default constructor
     */
    public DrawCircle() {
    }

    /**
     * 
     */
    public void draw() {
        System.out.println("Circle Drawn.");
    }

}