package design_patterns.strategy_pattern.hw;

/**
 * 
 */
public class DrawLine implements DrawCanvas {

    /**
     * Default constructor
     */
    public DrawLine() {
    }

    /**
     * 
     */
    public void draw() {
        System.out.println("Line Drawn.");
    }

}