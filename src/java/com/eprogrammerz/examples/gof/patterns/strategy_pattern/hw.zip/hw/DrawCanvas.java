package design_patterns.strategy_pattern.hw;

/**
 * 
 */
public interface DrawCanvas {

    /**
     * 
     */
    void draw();

}