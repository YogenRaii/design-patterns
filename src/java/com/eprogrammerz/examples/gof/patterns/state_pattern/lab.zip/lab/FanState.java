package design_patterns.state_pattern.lab;

/**
 * Created by ${YogenRai} on 4/24/2016.
 */
public interface FanState {
    void printState();
    FanState nextState();
    FanState previousState();
}
