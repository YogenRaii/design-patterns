package design_patterns.state_pattern.lab;

/**
 * Created by ${YogenRai} on 4/24/2016.
 */
public class Off implements FanState {
    @Override
    public void printState() {
         System.out.println(" fan is off ");
    }

    @Override
    public FanState nextState() {
        return new LowSpeed();
    }

    @Override
    public FanState previousState() {
        return new HighSpeed();
    }
}
